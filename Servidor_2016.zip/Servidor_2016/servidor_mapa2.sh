java -cp jade.jar:Servidor_2016.jar:Monitor_2015.jar:. jade.Boot -agents entorno3213:agente.Entorno\(-map,mapa2.txt,-time,500\)
